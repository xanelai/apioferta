module.exports = {
  username :  "root",
  password : "fenasantma",
  database : "oferta",
  host : "localhost",
  dialect :  "mysql",
}


// module.exports = {
//   username :  process.env.JOVEN_DB_USER,
//   password : process.env.JOVEN_DB_PASS,
//   database : process.env.JOVEN_DB,
//   host : "localhost",
//   dialect :  "mysql",
// }